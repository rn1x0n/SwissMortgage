
## @knitr , echo=FALSE, message = FALSE, results='hide'
library(SwissMortgage)
library(knitr)
library(ggplot2)
options(scipen=999)
opts_chunk$set(fig.keep="none")
options(markdown.HTML.header = system.file('misc', 'vignette.css', package='knitr'))


## @knitr 
currentFixRates <- c(0.980, 0.960, 1.020, 1.150, 1.300, 1.460, 1.620, 1.780, 1.920, 2.060)


## @knitr , fig.width = 7, fig.height = 5
flexRate <- flex.rate(times = c(0, 5), rates = c(1, 3), last.time = 10)
ggplot(flexRate, aes(x = month, y = rate)) + geom_line()


## @knitr , tidy=FALSE
shinyPlan <- list(
  "Amortization - 10 year fix" = list(
    list(debt = 100000, fix.rate = TRUE,  period = 10, interest.only = FALSE,  amortization.period = 20)
  ),
  "5 year fix, and part pay off" = list(
    list(debt = 300000, fix.rate = TRUE, period = 5, interest.only = TRUE),
    list(debt = 100000, fix.rate = TRUE, period = 5, interest.only = TRUE)
  ),
  "LIBOR" = list(
    list(debt = 200000, fix.rate = FALSE, period = 10, interest.only = TRUE)
  )
)


## @knitr , tidy=FALSE
plan <- shinyPlan2plan(
  shinyPlan = shinyPlan,
  currentFixRates = currentFixRates,
  flexRate = flexRate
  )


## @knitr 
pay <- plan.pay(plan)


## @knitr , eval=FALSE
## summaryPay(pay)


## @knitr , echo=FALSE, results='asis'
summaryPay(pay, xtable = TRUE)


## @knitr , fig.width = 9, fig.height = 5
ribbon.plot.pay(pay)


## @knitr , fig.width = 9, fig.height = 5
line.plot.pay(pay)


